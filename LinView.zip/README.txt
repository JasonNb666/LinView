# LinView (ENCMP 100 Contest)

LinView (Linear Algebra Visualization) is designed to bridge the gap between abstract mathematical concepts and intuitive understanding. By transforming linear algebra into dynamic visual representations, the program enables users to explore how equations, vectors, and matrices behave both algebraically and geometrically. Users can input linear systems, vector equations, or matrices, and then explore their relationships through operations. Our goal is to help users develop a deeper understanding on fundamental linear algerbra.

## Files Included

- "LinView.py" (main program)


## Sample Inputs

### Input 1 Goal
Verify App introdunction, Journal, 2D equation plotting, and Gaussian elimination.

1
2
3
x + y = 2
x - y = 0
q
1
0
0

### Input 2 Goal
Verify fraction input and standard equation solving with non-integer values.

4
3
-x+1/2y=3/2
2x-y=0
q
1
0
0

### Input 3 Goal
Verify direct matrix-row input mode with fractions and negative values

3
1/2 -1 3
2 0 -4
q
3
0
0

### Input 4 Goal
Verify 2D vector-equation comparison and intersection visualization.

3
r = (0,0) + t(1,1)
1
r = (1,0) + t(-1,1)
q
0
0

### Input 5 Goal
Verify 3D point-to-line distance computation and visualization.

3
r = (0,0,0) + t(1,1,1)
2
1 0 0
0
0

### Input 6 Goal
Test "Explore system of linear equations" functions in one run (equation mode, matrix operations, vector-line/plane comparison, and point-to-line distance).

3
x+y=2
x-y=0
q
3
1
2
1
1 0
0 1
q
2
2
1 0
0 1
q
2
3
1 0
0 1
q
4
0
3
r=(0,0,0)+t(1,1,1)
1
x+y+z=1
2
1 0 0
0
0