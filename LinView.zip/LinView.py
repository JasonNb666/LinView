﻿# -*- coding: utf-8 -*-
"""
Created on Thu Feb 19 13:08:46 2026

@author: jcyang
"""

import matplotlib
matplotlib.use("TkAgg")
import numpy as np
import tkinter as tk
from fractions import Fraction
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
import math

#
# GLOBAL STORAGE
equations = []
plt.ion()  
current_point = None
current_direction = None
display_mode = "decimal"  # or "fraction"
EPS = 1e-9
# Create one hidden root window
root = tk.Tk()
root.withdraw()   # hide the main Tk window


# ===========================================================================
# UI functions
# ===========================================================================

def main_menu_UI():
    global display_mode
    while True:
        print("\nWelcome to LinView!")
        print("Type in the number to choose your next move:")
        print("\n1) App introduction")
        print("2) Journal")
        print("3) Explore system of linear equations")
        print(f"4) Switch display mode (current: {display_mode})")
        print("0) Exit")

        choice = input("Enter choice: ").strip()

        if choice == "1":
            text_window("intro")
        elif choice == "2":
            text_window("journal")
        elif choice == "3":
            explore_LinAlg_UI()
        elif choice == "4":
            display_mode = "fraction" if display_mode == "decimal" else "decimal"
            print(f"Display mode set to {display_mode}.")
        elif choice == "0":
            print("Thanks for using LinView.")
            return
        else:
            print("Invalid choice.")



def text_window(message):
    window = tk.Toplevel(root)
    window.title("Information")

    text = tk.Text(window)
    text.pack(padx=10, pady=10)

    if message == "journal":
        text.insert(tk.END,
            "\nVersion 1.0: Built the basic UI, convert equations to matrix\n"
            "\nVersion 1.1: Added Gaussian elimination, convert to RREF\n"
            "\nVersion 1.2: Separated the display of app introduction and journal from console. Enabled 2D graph visualization.\n"
            "\nVersion 1.3: The program can automatically visualize equations, detect both vector and general equations.\n"
            "\nVersion 1.4: Several features about vector equation are added. 3D graph visualization was added\n"
            "\nVersion 1.5: Improved equation input detection; invalid inputs are now rejected.\n"
            "\nVersion 2.0: Upgraded the eqaution visualization method to become interactive and more visually intuitive. "
            "The program’s basic functions were completed.\n"
            "\nVersion 2.1: Three different Matrix operations are added to the program. The program now supports coefficient input for unaugmented matrix.\n"
            "\nVersion 2.2: Added a feature to find the projection and distance between a point and a vector. Support for fraction inputs in equations.\n"
            "\nVersion 2.3: Improved UI interactions to prevent accidental program termination or crashes. The interfaces are now connected more smoothly.\n"
            "\nVersion 3.0: Enhanced visualization to support vector-vector and vector-plane comparisons, enforced matrix row input validation.\n"
            "The project shifted its focus toward visualization and educational exploration.\n"
            "\nVersion 3.1: Adjusted equation visualization, flexible plotting range, and direction arrow assigned to 3D vector equations.\n"
            "\nVersion 3.2: Added decimal/fraction display mode, improved equation validation, and printed line-line intersection points. Adjusted 3D distance plot scaling.\n"
            "\nVersion 3.3: Aligned the console UI format, sorted the code, removed redundant sections, and interpreted important functions.\n"
            "\nVersion 3.4: References added, updated instructions, standardized variable names, and enhanced code readability.\n"
            "\nBeta Version: Finalized the program, stress-tested many possible inputs, fixed some bugs.\n"
        )

    elif message == "intro":
        text.insert(
            tk.END,
            "LinView: A linear algebra learning tool.\n"
            "\nA few default settings:\n"
            "- Equation input builds an augmented matrix; the last column is the constants.\n"
            "- Variable order is inferred from your input and shown before the matrix.\n"
            "- If you enter rows directly, LinView treats it as a plain (unaugmented) matrix.\n"
            "- You can type q to finish input.\n"
            "- Display mode only changes output formatting (decimal vs fraction).\n"
            "\nVector tools:\n"
            "- Compare two vector equations (or compare a vector line with a plane).\n"
            "- Find the shortest distance from a point to the current vector line.\n"
            "\nMatrix tips:\n"
            "- Dot product requires inner dimensions to match.\n"
            "- Cross product works only for 3D vectors.\n"
            "- Inverse can only be found for unaugmented square matrices.\n"
            "\nPlotting tips:\n"
            "- Graph ranges auto-scale based on intercepts.\n"
            "- 2D/3D equation plots only appear when the system has 2 or 3 variables.\n"
            "\nExit:\n"
            "- Choose 0 in any menu to go back or exit\n"
            "\n\nReferences & thanks:\n"
            "- Support from ChatGPT and Codex for code assistance, debugging, and coding grammar correction.\n"
            "- Brennan Waters's video Engineering Calculator inspired some designs.\n"
            "- Initial inspiration came from eMathHelp's RREF matrix calculator.\n"
            "- Matplotlib library for mplot3d Axes3D, plot_surface and matplotlib.pyplot.ion.\n"
            "- Python library for the Tcl/Tk GUI toolkit.\n"
            "- NumPy library for linear algebra commands (e.g. numpy.linalg.det, numpy.linalg.inv, numpy.linalg.norm).\n"
            "- Thanks to Math 102 professor Jie Sun for foundational linear algebra knowledge and office-hour support.\n"
            "- Example question selected from Math 102 online assignment 3.\n"
        )

    text.config(state="disabled")  # read-only
    window.grab_set()       # focus stays on this window
    window.focus_force()    # bring to front
    window.wait_window()   
    return

    
def explore_LinAlg_UI():
    equations.clear()

    print("\nEquation Input")
    print("Enter one of the following:")
    print("- Linear equation (e.g. 2x + 3y = 5)")
    print("- Vector equation (e.g. r = (1,2,3) + t(-1,-2,-3))")
    print("- Matrix row: (e.g. 2/5 1 -1/2)")
    print("Enter q to finish.\n")

    vector_equation = None
    first_input = True

    while True:
        eq = input("Enter equation: ").strip()

        # ---------- QUIT ----------
        if eq.lower() == "q":
            if first_input:
                return
            else:
                break

        if eq == "":
            print("Invalid input. Enter an equation or a matrix row.")
            continue

        first_input = False

        # ---------- MATRIX ROW INPUT ----------
        parts = eq.split()

        # Step 1: check if all inputs are valid numbers or fractions
        is_valid = True
        for p in parts:
            try:
                Fraction(p)   # try converting
            except ValueError:
                is_valid = False
                break
        
        # Step 2: if valid, build the matrix
        if is_valid:
            matrix = []
            # first row
            first_row = []
            for x in parts:
                first_row.append(float(Fraction(x)))
            matrix.append(first_row)
        
            print("Enter additional matrix rows, or enter q to finish.")
        
            # Step 3: keep asking for more rows
            while True:
                row_values = prompt_row_values("Enter matrix row (or q): ")
        
                if row_values is None:   # user typed q
                    break
        
                if row_values == []:     # empty input, skip
                    continue

                if len(row_values) != len(first_row):
                    print("Invalid input. All matrix rows must have the same number of values.")
                    continue

                matrix.append(row_values)
        
            # Step 4: display matrix
            print("\nMatrix:")
            print_matrix(matrix)
            next_step_menu(matrix, augmented=False)
            return

        # ---------- VECTOR EQUATION ----------
        if "," in eq and "(" in eq and ")" in eq:
            groups = [p.split(")")[0] for p in eq.split("(")[1:]]
            # For each piece, split at ")" and take what's before it; Splits the string at every "("

            if len(groups) == 3:
                print("Invalid format. Parametric plane equations are not supported.")
                continue

            if len(groups) == 2:
                point, direction = read_vector_input(eq)
                if point is None:
                    print("Invalid format. Example: r = (1,2,3) + t(4,5,6)")
                    continue

                if len(point) != len(direction):
                    print("Invalid input. Point and direction must have the same dimension.")
                    continue
                if all(abs(v) < EPS for v in direction):
                    print("Invalid input. Direction vector cannot be all zeros.")
                    continue

                vector_equation = eq

                global current_point, current_direction
                current_point = point
                current_direction = direction

                break

        # ---------- GENERAL LINEAR EQUATION ----------
        elif "=" in eq and "(" not in eq:
            processed = process_input_eq(eq)
            if processed is not None:
                equations.append(processed)
            else:
                print("Invalid format. Example: 2x + 3y = 5")
            continue

        else:
            print("Invalid format. Example: 2x + 3y = 5")
            continue

    # ---------- VECTOR MODE ----------
    if vector_equation is not None:
        # Create a list of dictionaries
        vector_list = [{"point": point, "direction": direction, "label": "Equation 1"}]
        visualize_vector(vector_list)
        plt.show(block=True)
        vector_eq_menu()
        return

    # ---------- INVALID ----------
    if not equations:
        print("Invalid input. Enter at least one equation or matrix row.")
        explore_LinAlg_UI()
        return

    # ---------- MATRIX FROM EQUATIONS ----------
    variables, matrix = generate_matrix(equations)

    print("\nVariable Order:", variables)

    print("\nAugmented Matrix:")
    print_matrix(matrix, augmented=True)

    visualize_equations(matrix)
    plt.show(block=True)

    next_step_menu(matrix, augmented=True)


def next_step_menu(matrix, augmented=False):
    while True:
        print("\nMatrix Operations")
        print("1) Gaussian elimination (RREF)")
        print("2) Matrix operation")

        

        if not augmented:
            print("3) Transpose")
            rows = len(matrix)
            cols = len(matrix[0])
            if rows == cols and rows > 0:  # square matrix only for finding inverse
                print("4) Inverse")
        else:
            print("3) Remove augmented column")

        print("0) Back")
        
        choice = input("Enter choice: ").strip()

        if choice == "1":
            rref = gaussian_elimination(matrix)
            print("\nRREF:")
            print_matrix(rref, augmented)
            matrix = rref

        elif choice == "2":
            result_matrix, new_augmented = matrix_operation(matrix, augmented)
            if result_matrix is not None:
                matrix = result_matrix
                augmented = new_augmented

        elif choice == "4" and augmented == False:
            result_matrix = matrix_inverse(matrix)
            if result_matrix is not None:
                matrix = result_matrix

        elif choice == "3" and augmented == False:
            result_matrix = matrix_transpose(matrix)
            if result_matrix is not None:
                matrix = result_matrix

        elif choice == "3" and augmented == True:
            result_matrix = remove_augmented_col(matrix)
            if result_matrix is not None:
                matrix = result_matrix
                augmented = False

        elif choice == "0":
            return
        else:
            print("Invalid choice. Enter a listed option.")
            continue


def vector_eq_menu():
    
    print("\nVector Equation")
    print("1) Compare with another equation")
    print("2) Find the shortest distance to a point")
    print("0) Back")
    
    choice = input("Enter choice: ").strip()
    
    if(choice == "1"):
        compare_vector_equations()
    elif(choice == "2"):
        distance_finding()
    elif(choice == "0"):
        return
    else:
        print("Invalid choice. Enter a listed option.")

    vector_eq_menu()

# ===========================================================================
#  Input interpretation
# ===========================================================================

def read_vector_input(raw_text):
    """
    Parse a vector equation like:
    r = (x,y,z) + t(a,b,c)
    """
   
    eq = raw_text.replace(" ", "") 
    
    # Basic format check: must contain commas and parentheses
    if "," not in eq or "(" not in eq or ")" not in eq:
        return None, None

    # Extract contents inside parentheses
    # Example: "(1,2,3)+t(4,5,6)" 鈫?['1,2,3', '4,5,6']
    groups = [p.split(")")[0] for p in eq.split("(")[1:]]
    if len(groups) != 2:
        return None, None

    try:
        
        # Convert first group into point coordinates
        point = [float(Fraction(x)) for x in groups[0].split(",")]
        
        # Convert second group into direction vector
        direction = [float(Fraction(x)) for x in groups[1].split(",")]
        
        return point, direction
    
    # If conversion fails (e.g., invalid number), return invalid
    except ValueError:
        return None, None


def read_plane_input(raw_text):
    """
    Parse a plane equation like: ax + by + cz = d
    Returns (a, b, c, d) or None if invalid.
    """
    eq = raw_text.replace(" ", "")
    if "=" not in eq:
        return None

    left, right = eq.split("=")
    # Split into left side (ax+by+cz) and right side (d)

    try:
        d = float(Fraction(right))
        # Convert right side into a number
        
    except Exception:
        return None

    coeffs = extract_coefficients(left, ["x", "y", "z"])
    # Extract coefficients of x, y, z from the left side
    # Example: "2x-3y+z" -->"{"x":2, "y":-3, "z":1}
    
    if coeffs is None:
        return None

    a = coeffs["x"]
    b = coeffs["y"]
    c = coeffs["z"]
    # Assign coefficients to variables

    if abs(a) < EPS and abs(b) < EPS and abs(c) < EPS:
        # Check if all coefficients are zero (not a valid plane)
        return None

    return a, b, c, d
    # Return plane in standard form ax + by + cz = d


def extract_coefficients(left_text, variables):
    """
    Parse the left side of a linear equation like: 2x-3y+z
    Returns a dict of coefficients for the given variables, or None if invalid.
    """
    # Start all coefficients at 0 (e.g., x, y, z -> 0.0)
    coeffs = {var: 0 for var in variables}
    # Track the sign (+ or -) that applies to the current term
    sign = 1
    # Build up the numeric part of a term (e.g., "3" in "3x")
    number = ""
    # Store the variable part of a term (e.g., "x" in "3x")
    variable = ""

    for ch in left_text + "+":
        # The extra "+" at the end flushes the final term through this same logic
        if ch in "+-":
            if variable:
                if variable not in coeffs:
                    return None
                # If number is empty, treat it as 1 (so "x" means 1x)
                coeff = read_number(number)
                coeffs[variable] += sign * coeff
            # Update sign for the next term, then reset buffers
            sign = 1 if ch == "+" else -1
            number = ""
            variable = ""
        elif ch.isdigit() or ch == "." or ch == "/":
            # Part of a (possibly fractional) numeric coefficient
            number += ch
        elif ch.isalpha():
            # The variable symbol (like x, y, or z)
            variable = ch
        else:
            return None

    return coeffs


def read_number(token):
    """Parse a coefficient like '2', '3.5', or '2/5' into float."""
    if token == "":
        return 1
    try:
        return float(Fraction(token))
    except Exception:
        return float(token)
  
    
def prompt_row_values(prompt):
    """
    Prompt for a row of numeric values separated by spaces.
    Returns a list of floats or None if the input is 'q'.
    """
    raw = input(prompt).strip()
    if raw.lower() == "q":
        return None
    if raw == "":
        print("Invalid input. Matrix row is empty. Example: 1 2 3")
        return []
    try:
        return [float(Fraction(x)) for x in raw.split()]
    except ValueError:
        print("Invalid format. Use numbers or fractions separated by spaces. Example: 1 2 -1/2")
        return []
    
    
def process_input_eq(eq):
    # Normalize and validate a linear equation, then return "left=right".
    # Input: eq (string). Output: formatted equation string or None if invalid.
    eq = eq.strip()
    if "=" not in eq:
        return None

    # Split only at the first '=' so extra '=' in input is rejected by parsing.
    left, right = eq.split("=", 1)
    left = left.replace(" ", "")
    right = right.replace(" ", "")
    if left == "" or right == "":
        return None

    def parse_side(text):
        # Parse an expression into variable coefficients and a constant term.
        # Supported term shapes: x, -x, 2x, 1/2x, 3, -4/5
        # Multiplication syntax with '*' is intentionally invalid.
        if text == "" or "*" in text:
            return None

        if text[0] not in "+-":
            text = "+" + text

        coeffs = {}
        constant = Fraction(0)
        explicit_zero_vars = set()

        i = 0
        n = len(text)
        while i < n:
            sign_char = text[i]
            if sign_char not in "+-":
                return None
            sign = 1 if sign_char == "+" else -1
            i += 1

            j = i
            while j < n and text[j] not in "+-":
                j += 1
            term_text = text[i:j]
            if term_text == "":
                return None

            variable_chars = [ch for ch in term_text if ch.isalpha()]
            if len(variable_chars) > 1:
                return None

            if len(variable_chars) == 1:
                variable_symbol = variable_chars[0]
                variable_index = term_text.find(variable_symbol)
                # Variable must appear once and at the end: "2x", "x", "1/2x"
                if variable_index != len(term_text) - 1:
                    return None
                coefficient_text = term_text[:variable_index]
                if coefficient_text == "":
                    coef = Fraction(1)
                else:
                    try:
                        coef = Fraction(coefficient_text)
                    except Exception:
                        return None
                coef *= sign
                coeffs[variable_symbol] = coeffs.get(variable_symbol, Fraction(0)) + coef
                # Preserve variables explicitly written with 0 coefficient (e.g., "0z").
                if coef == 0:
                    explicit_zero_vars.add(variable_symbol)
            else:
                try:
                    constant += sign * Fraction(term_text)
                except Exception:
                    return None

            i = j

        return coeffs, constant, explicit_zero_vars

    # Parse both sides; if invalid, reject
    left_parsed = parse_side(left)
    right_parsed = parse_side(right)
    if left_parsed is None or right_parsed is None:
        return None

    left_coeffs, left_const, left_zero_vars = left_parsed
    right_coeffs, right_const, right_zero_vars = right_parsed
    explicit_zero_vars = left_zero_vars.union(right_zero_vars)

    # Move all variable terms to the left by subtracting RHS coefficients
    for var, coef in right_coeffs.items():
        left_coeffs[var] = left_coeffs.get(var, Fraction(0)) - coef

    if not any(abs(float(c)) > EPS for c in left_coeffs.values()):
        return None

    # Move constants to the right
    new_right = right_const - left_const

    # Rebuild the left side in a normalized order
    parts = []
    for var in sorted(left_coeffs.keys()):
        coef = left_coeffs[var]
        if abs(float(coef)) < EPS:
            if var in explicit_zero_vars:
                term = f"0{var}"
                if parts:
                    parts.append(f"+{term}")
                else:
                    parts.append(term)
            continue
        if coef == 1:
            term = f"{var}"
        elif coef == -1:
            term = f"-{var}"
        else:
            term = f"{coef}{var}"
        if term.startswith("-"):
            parts.append(term)
        else:
            if parts:
                parts.append(f"+{term}")
            else:
                parts.append(term)

    new_left = "".join(parts)
    if new_left == "":
        return None

    return f"{new_left}={float(new_right)}"

# ===========================================================================
#  Math utilities
# ===========================================================================

def line_intersection_2d(p1, d1, p2, d2):
    """Return intersection point of two 2D lines, or None if parallel."""
    a11 = d1[0]
    a12 = -d2[0]
    a21 = d1[1]
    a22 = -d2[1]
    det = a11 * a22 - a12 * a21
    if abs(det) < EPS:
        return None
    b1 = p2[0] - p1[0]
    b2 = p2[1] - p1[1]
    t = (b1 * a22 - b2 * a12) / det
    return p1 + t * d1


def line_intersection_3d(p1, d1, p2, d2):
    """Return intersection point of two 3D lines, or None if no intersection."""
    # Use x and y components to solve
    a = np.array([
        [d1[0], -d2[0]],
        [d1[1], -d2[1]]
    ])
    b = np.array([
        p2[0] - p1[0],
        p2[1] - p1[1]
    ])

    det = np.linalg.det(a)
    if abs(det) < EPS:
        print("No intersection. Lines are parallel in the XY projection.")
        return None  # parallel or no unique solution

    t, s = solve_linear_system(a, b)
    if t is None:
        return None

    # Compute intersection point
    point = p1 + t * d1

    # Check z consistency
    z1 = p1[2] + t * d1[2]
    z2 = p2[2] + s * d2[2]

    if abs(z1 - z2) > EPS:
        print("No intersection. Z components do not match.")
        return None  # lines do not actually intersect

    return point


def solve_linear_system(a, b):
    """
    Solve a 2x2 linear system A x = b using the program's RREF.
    Returns (x0, x1) or (None, None) if no unique solution.
    """
    # Build augmented matrix [A | b]
    aug = np.array([
        [a[0, 0], a[0, 1], b[0]],
        [a[1, 0], a[1, 1], b[1]]
    ], dtype=float)

    rref = gaussian_elimination(aug)

    # Check for singular/degenerate cases (no unique solution)
    if abs(np.linalg.det(a)) < EPS:
        return None, None

    # In RREF form, solution is the last column
    return rref[0, 2], rref[1, 2]


def compare_vector_equations():
    global current_point, current_direction

    print("\nCompare Equations")
    print("Enter q to cancel.\n")

    # Start with the current vector equation as Equation 1
    vector_list = [
        {"point": current_point, "direction": current_direction, "label": "Equation 1"}
    ]

    while True:
        raw = input("Enter equation: ").strip()
        if raw.lower() == "q":
            return
        point2, direction2 = read_vector_input(raw)
        if point2 is None:
            # If it's not a vector equation, try reading it as a plane
            plane_coeffs = read_plane_input(raw)
            if plane_coeffs is None:
                print("Invalid format. Example: 2x + 3y + z = 4")
                continue

            a, b, c, d = plane_coeffs
            # Check if the line intersects the plane (solve for t)
            denom = a * current_direction[0] + b * current_direction[1] + c * current_direction[2]
            if abs(denom) > EPS:
                t_hit = (d - a * current_point[0] - b * current_point[1] - c * current_point[2]) / denom
                hit = np.array(current_point, dtype=float) + t_hit * np.array(current_direction, dtype=float)
                print("Intersection:", format_vector(hit))
            # Visualize the line and plane together
            visualize_vector_and_plane(current_point, current_direction, plane_coeffs)
            plt.show(block=True)
            return

        if len(point2) != len(current_point):
            print("Invalid input. Equations must be in the same dimension.")
            return
        
        # Add the new vector equation to the comparison list
        vector_list.append({
            "point": point2,
            "direction": direction2,
            "label": f"Equation {len(vector_list) + 1}"
        })

        fig = visualize_vector(vector_list)
        if fig is None:
            return
        ax = fig.axes[0]
        if len(vector_list) == 2:
            # If we have exactly two lines, try to mark their intersection
            p1 = np.array(vector_list[0]["point"], dtype=float)
            d1 = np.array(vector_list[0]["direction"], dtype=float)
            p2 = np.array(vector_list[1]["point"], dtype=float)
            d2 = np.array(vector_list[1]["direction"], dtype=float)
            if len(current_point) == 2:
                hit = line_intersection_2d(p1, d1, p2, d2)
                if hit is not None:
                    ax.scatter(hit[0], hit[1], color="black", s=40, label="Intersection")
                    ax.legend()
            if len(current_point) == 3:
                hit = line_intersection_3d(p1, d1, p2, d2)
                if hit is not None:
                    ax.scatter(hit[0], hit[1], hit[2], color="black", s=40, label="Intersection")
                    ax.legend()
        plt.show(block=True)
        
        
def distance_finding():
    """
    Vatiables' representation: 
        p = starting point
        d = direction vector
        q = user input point
    """
    global current_point, current_direction

    print("\nPoint-to-Line Distance")

    p = np.array(current_point)
    d = np.array(current_direction)
    dim = len(p)

    while True:
        raw = input(f"Enter point coordinates ({dim} numbers, or q): ").strip()
        # strip() removes whitespace at the beginning and end
        if raw.lower() == "q":
            return
        raw = raw.replace(",", " ")
        # Converts commas into spaces (if there is any)
        parts = raw.split()
        # splits by any whitespace. "1  2  3" ---> ["1", "2", "3"]
        if len(parts) != dim:
            print(f"Invalid input. Enter exactly {dim} numbers.")
            continue
        
        # Try-except function prevents the program from crashing while accepting all valid inputs
        try:
            q = np.array([float(Fraction(x)) for x in parts]) 
            # Fraction(x) can interpret more types of numeric input:
            # Converts to a decimal number for clearer display, avoiding complex fractions.
            break
        except ValueError:
            print("Invalid numbers. Example: 1 2 -3")

    # ---------- projection math ----------
    v = q - p
    v_dot_d = np.dot(v, d)
    d_dot_d = np.dot(d, d)
    v_dot_v = np.dot(v, v)

    t = v_dot_d / d_dot_d
    closest = p + t * d

    # ---------- distance calculation ----------
    projection_length_sq = (v_dot_d ** 2) / d_dot_d
    distance_sq = v_dot_v - projection_length_sq

    if distance_sq < 0:
        distance_sq = 0

    # ---------- distance output ----------
    distance = math.sqrt(distance_sq)
    print("\nDistance:", format_number(distance))
    print("Closest point:", format_vector(closest))

    # ---------- visualization ----------
    visualize_point_line_distance(p, d, q, closest)
    plt.show(block=True)
    
    
def gaussian_elimination(matrix):

    # Convert list ---> numpy array
    matrix = np.array(matrix, dtype=float, copy=True)

    rows, cols = matrix.shape
    pivot_col = 0
    pivot_row = 0
    tolerance = EPS

    while pivot_row < rows and pivot_col < cols:

        # Find pivot
        search_row = pivot_row
        while search_row < rows and abs(matrix[search_row, pivot_col]) < tolerance:
            search_row += 1

        # If no pivot in this column ---> move to next column
        if search_row == rows:
            pivot_col += 1
            continue

        # Swap rows
        matrix[[pivot_row, search_row]] = matrix[[search_row, pivot_row]]

        # Normalize pivot row
        pivot_value = matrix[pivot_row, pivot_col]
        matrix[pivot_row] = matrix[pivot_row] / pivot_value

        # Eliminate other rows
        for r in range(rows):
            if r != pivot_row:
                factor = matrix[r, pivot_col]
                matrix[r] -= factor * matrix[pivot_row]

        pivot_col += 1
        pivot_row += 1

    # Clean very small values
    matrix[np.abs(matrix) < tolerance] = 0

    return matrix


# ===========================================================================
#  Matrix constructions
# ===========================================================================


def format_number(x):
    """Format a number to at most 2 decimal places without trailing zeros."""
    value = float(x)

    if display_mode == "fraction":
        frac = Fraction(value).limit_denominator(1000)
        if frac == 0:
            return "0"
        return str(frac.numerator) if frac.denominator == 1 else f"{frac.numerator}/{frac.denominator}"

    text = f"{round(value, 2):.2f}".rstrip("0").rstrip(".")
    return "0" if text in ("", "-0") else text


def format_vector(v):
    """Format a vector nicely."""
    
    formatted = []

    for val in v:
        formatted.append(format_number(val))

    return "(" + ", ".join(formatted) + ")"


def generate_matrix(equations):
    # Step 1: detect variables
    variables = []
    for eq in equations:
        for ch in eq:
            if ch.isalpha() and ch not in variables:
                variables.append(ch)
    variables.sort()

    # Step 2: build augmented matrix
    rows = len(equations)
    cols = len(variables) + 1
    matrix = np.zeros((rows, cols), dtype=float)

    i = -1
    for eq in equations:
        i += 1
        left, right = eq.split("=")
        matrix[i, -1] = float(right)

        coeffs = extract_coefficients(left, variables)

        for var, coeff in coeffs.items():
            col = variables.index(var)
            matrix[i, col] += coeff

    return variables, matrix


def print_matrix(matrix, augmented=False):

    if not isinstance(matrix, np.ndarray):
        matrix = np.array(matrix, dtype=float)

    rows, cols = matrix.shape

    for i in range(rows):
        print("[", end=" ")

        for j in range(cols):

            val = matrix[i, j]

            if abs(val) < EPS:
                val = 0

            # Format numbers based on current display mode
            text = format_number(val)

            if augmented and j == cols - 1:
                # Visual separator before the constants column
                print("|", end=" ")

            print(f"{text:>8}", end=" ")

        print("]")


# ===========================================================================
#  Matrix operations
# ===========================================================================

def prompt_second_matrix():
    print("\nSecond Matrix Input")
    print("Enter matrix rows:")
    print("- Example: 2 3 -1")
    print("- Enter q on a new line to finish")
    print("- Enter q now to cancel\n")

    second = []

    # Require the first non-empty row
    while True:
        first_row = prompt_row_values("Enter matrix row 1 (or q): ")
        if first_row is None:
            return None
        if first_row == []:
            continue
        second.append(first_row)
        break

    expected_cols = len(second[0])

    # Keep collecting rows until user finishes.
    while True:
        next_row = prompt_row_values(f"Enter matrix row {len(second) + 1} (or q): ")
        if next_row is None:
            break
        if next_row == []:
            continue
        if len(next_row) != expected_cols:
            print(f"Invalid input. Enter exactly {expected_cols} numbers.")
            continue
        second.append(next_row)

    return second


def is_valid_cross_size(first_matrix):
    try:
        return np.array(first_matrix).size == 3
    except Exception:
        return False
    
    
def matrix_operation(matrix, augmented=False):
    # Cross product is only meaningful for non-augmented 3-element vectors.
    show_cross = (not augmented) and is_valid_cross_size(matrix)

    print("\nMatrix Operation")
    print("1) Addition")
    print("2) Subtraction")
    print("3) Dot product")
    if show_cross:
        print("4) Cross product")
    print("0) Back")

    choice = input("Enter choice: ").strip()

    if choice == "0":
        return None, augmented

    if choice not in ["1", "2", "3", "4"]:
        print("Invalid choice. Enter a listed option.")
        return matrix_operation(matrix, augmented=augmented)

    if choice == "4" and not show_cross:
        print("Invalid operation. Cross product requires 3D vectors.")
        return None, augmented

    
    # Arop the augmented column automatically for operating dot product.
    if choice == "3" and augmented:
        matrix = remove_augmented_col(matrix)

    # Ask for the second operand after operation selection/validation.
    second_matrix = prompt_second_matrix()
    if second_matrix is None:
        return None, augmented


    if choice == "3":
        result = dot_product(matrix, second_matrix)
        if result is None:
            return None, augmented
        print("\nResult:")
        print_matrix(result)
        return result, False

    if choice == "4":
        result = cross_product(matrix, second_matrix)
        if result is None:
            return None, augmented
        print("\nResult:")
        print_matrix(result)
        return result, False

    if choice == "1":
        result = matrix_addition(matrix, second_matrix, 1)
        if result is None:
            return None, augmented
        print("\nResult:")
        print_matrix(result, augmented)
        return result, augmented

    if choice == "2":
        result = matrix_addition(matrix, second_matrix, -1)
        if result is None:
            return None, augmented
        print("\nResult:")
        print_matrix(result, augmented)
        return result, augmented


def dot_product(matrix1, matrix2):
    m1 = np.array(matrix1)
    m2 = np.array(matrix2)

    if m1.shape[1] != m2.shape[0]:
        print("Invalid operation. Incompatible matrix sizes for dot product.")
        return None

    return np.dot(m1, m2)


def cross_product(matrix1, matrix2):

    v1 = np.array(matrix1).flatten()
    v2 = np.array(matrix2).flatten()

    if v1.size != 3 or v2.size != 3:
        print("Invalid operation. Cross product requires 3D vectors.")
        return None

    return [np.cross(v1, v2)]


def matrix_addition(matrix1, matrix2, sign):

    m1 = np.array(matrix1)
    m2 = np.array(matrix2)

    if m1.shape != m2.shape:
        print("Invalid operation. Matrix sizes must match.")
        return None

    return m1 + sign * m2


def matrix_inverse(matrix):
    print("\nInverse")

    matrix = np.array(matrix, dtype=float)
    rows, cols = matrix.shape

    det_val = float(np.linalg.det(matrix))
    if abs(det_val) < EPS:
        print("No inverse. Determinant is 0.")
        return None

    matrix = np.linalg.inv(matrix)
    print("\nInverse:")
    print_matrix(matrix)
    return matrix


def matrix_transpose(matrix):
    print("\nTranspose:")
    matrix = np.array(matrix, dtype=float, copy=True).T
    print_matrix(matrix)
    return matrix


def remove_augmented_col(matrix):
    print("\nRemove Augmented Column")

    matrix = np.array(matrix, dtype=float, copy=True)
    rows, cols = matrix.shape


    matrix = matrix[:, :-1]
    print("\nMatrix:")
    print_matrix(matrix)
    return matrix
   
 
# ===========================================================================
#  Visualization functions
# ===========================================================================
    
def visualize_vector(vector_list):
    """
    Plot one or more vector equations.
    vector_list is a list of dictionaries
    """
    
    # Infer plotting dimension from the first vector entry.
    dimension = len(vector_list[0]["point"])
    # Build a shared parameter range based on the largest coordinate magnitude
    # so each line is long enough to be visible on the graph.
    all_numbers = []
    for item in vector_list:
        all_numbers.extend(item["point"])
        all_numbers.extend(item["direction"])
    scale = max(1.0, max(abs(v) for v in all_numbers))
    t = np.linspace(-scale, scale, 200)

    # 2D branch: plot each parametric line and auto-fit symmetric x/y limits.
    if dimension == 2:
        fig, ax = plt.subplots()
        max_abs = 1.0
        for count, vector in enumerate(vector_list, start=1):
            point = np.array(vector["point"], dtype=float)
            direction = np.array(vector["direction"], dtype=float)
            x = point[0] + direction[0] * t
            y = point[1] + direction[1] * t
            ax.plot(x, y, label=f"Equation {count}")
            ax.scatter(point[0], point[1])
            max_abs = max(
                max_abs,
                float(np.max(np.abs(x))),
                float(np.max(np.abs(y))),
                abs(point[0]),
                abs(point[1])
            )

        limit = max_abs * 1.1
        ax.set_xlim(-limit, limit)
        ax.set_ylim(-limit, limit)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_title("2D Vector Equation" if len(vector_list) == 1 else "2D Vector Equation Comparison")
        ax.grid(True)
        ax.legend()
        return fig

    # 3D branch: plot each line, keep cubic aspect ratio, and draw axis guides.
    if dimension == 3:
        fig = plt.figure(figsize=(9, 7))
        ax = plt.axes(projection="3d")
        max_abs = 1.0
        for count, vector in enumerate(vector_list, start=1):
            point = np.array(vector["point"], dtype=float)
            direction = np.array(vector["direction"], dtype=float)
            x = point[0] + direction[0] * t
            y = point[1] + direction[1] * t
            z = point[2] + direction[2] * t
            ax.plot(x, y, z, label=f"Equation {count}")
            ax.scatter(point[0], point[1], point[2])
            max_abs = max(
                max_abs,
                float(np.max(np.abs(x))),
                float(np.max(np.abs(y))),
                float(np.max(np.abs(z))),
                abs(point[0]),
                abs(point[1]),
                abs(point[2])
            )

        limit = max_abs * 1.1
        ax.set_xlim(-limit, limit)
        ax.set_ylim(-limit, limit)
        ax.set_zlim(-limit, limit)
        ax.set_box_aspect([1, 1, 1])
        ax.plot([-limit, limit], [0, 0], [0, 0], color="gray")
        ax.plot([0, 0], [-limit, limit], [0, 0], color="gray")
        ax.plot([0, 0], [0, 0], [-limit, limit], color="gray")
        ax.scatter(0, 0, 0, color="black", s=20, label="Origin")
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_zlabel("z")
        ax.set_title("3D Vector Equation" if len(vector_list) == 1 else "3D Vector Equation Comparison")
        ax.grid(True)
        ax.legend()
        return fig
      
def visualize_equations(matrix):
    # Get matrix size and determine number of variables
    rows, cols = matrix.shape
    variables = cols - 1

    # Only support 2D lines or 3D planes
    if variables not in (2, 3):
        print("Graphing supports only 2D or 3D.")
        return None

    # ==================================================
    # 2D CASE: ax + by = c
    # ==================================================
    if variables == 2:
        # Create a 2D figure and axis
        fig, ax = plt.subplots()

        # Step 1: Find a good graph range
        intercepts = []
        
        for equation in matrix:
            a, b, c = equation  # ax + by = c
        
            # Find where the line crosses the x-axis
            if a != 0:
                x_intercept = c / a
                intercepts.append(x_intercept)
        
            # Find where the line crosses the y-axis
            if b != 0:
                y_intercept = c / b
                intercepts.append(y_intercept)
        
        # Choose a plotting limit based on intercepts
        if len(intercepts) > 0:
            max_value = max(abs(value) for value in intercepts)
            limit = max(1, max_value) * 1.2  # add some space
        else:
            limit = 5  # default range if nothing found
        
        # Step 2: Create x values for plotting
        x = np.linspace(-limit, limit, 400)
        
        # Step 3: Plot each line
        for i, equation in enumerate(matrix, start=1):
            a, b, c = equation
        
            # If b == 0, it's a vertical line (x = c/a)
            if b == 0:
                if a != 0:
                    x_intercept = c / a
                    ax.axvline(x_intercept, label = f"Eq{i}")
                continue
        
            # Rearrange ax + by = c to y = (c - ax)/b
            y = (c - a * x) / b
        
            ax.plot(x, y, label = f"Eq{i}")

        # Label and format the plot
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_title("2D Linear Equations")
        ax.grid(True)
        ax.legend()

        # Return figure so the caller controls plt.show()
        return fig

    # ==================================================
    # 3D CASE: ax + by + cz = d
    # ==================================================
    if variables == 3:
    
        # Step 1: Estimate a good graph range using intercepts
        intercepts = []
    
        for equation in matrix:
            a, b, c, d = equation  # ax + by + cz = d
    
            # x-intercept 
            if a != 0:
                x_intercept = d / a
                intercepts.append(x_intercept)
    
            # y-intercept 
            if b != 0:
                y_intercept = d / b
                intercepts.append(y_intercept)
    
            # z-intercept 
            if c != 0:
                z_intercept = d / c
                intercepts.append(z_intercept)
    
        # Decide how big the graph should be
        if len(intercepts) > 0:
            max_value = max(abs(value) for value in intercepts)
            limit = max(1, max_value) * 1.2  # add a bit of space
        else:
            limit = 5  # default size
    
        # Step 2: Create a grid of (x, y) values
        x = np.linspace(-limit, limit, 20)
        y = np.linspace(-limit, limit, 20)
        X, Y = np.meshgrid(x, y)
    
        # Step 3: Set up the 3D plot
        fig = plt.figure(figsize=(9, 7))
        ax = plt.axes(projection="3d")
    
        # Step 4: Plot each plane
        colors = plt.rcParams["axes.prop_cycle"].by_key().get(
            "color", ["tab:blue", "tab:orange", "tab:green", "tab:red"]
        )
        legend_handles = []
        for i, equation in enumerate(matrix, start=1):
            a, b, c, d = equation
            color = colors[(i - 1) % len(colors)]

            # Plot any valid plane orientation:
            # c != 0: solve for z
            # c == 0 and b != 0: solve for y
            # c == 0 and b == 0 and a != 0: solve for x
            if abs(c) > EPS:
                Z = (d - a * X - b * Y) / c
                ax.plot_surface(X, Y, Z, alpha=0.7, color=color)
            elif abs(b) > EPS:
                X2, Z2 = np.meshgrid(x, y)
                Y2 = (d - a * X2 - c * Z2) / b
                ax.plot_surface(X2, Y2, Z2, alpha=0.7, color=color)
            elif abs(a) > EPS:
                Y2, Z2 = np.meshgrid(x, y)
                X2 = (d - b * Y2 - c * Z2) / a
                ax.plot_surface(X2, Y2, Z2, alpha=0.7, color=color)

            legend_handles.append(
                Patch(facecolor=color, edgecolor=color, alpha=0.7, label=f"Eq{i}")
            )

        # Label and format the 3D plot
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_zlabel("z")
        ax.set_title("3D Plane Visualization")
        ax.set_box_aspect([1, 1, 1])
        ax.plot([-limit, limit], [0, 0], [0, 0], color="gray", linewidth=1)
        ax.plot([0, 0], [-limit, limit], [0, 0], color="gray", linewidth=1)
        ax.plot([0, 0], [0, 0], [-limit, limit], color="gray", linewidth=1)
        # Skip origin marker to reduce 3D redraw cost
        if legend_handles:
            ax.legend(handles=legend_handles, loc="best")

        # Return figure so the caller controls plt.show()
        return fig
    
    
def visualize_vector_and_plane(point, direction, plane_coeffs):
    """
    Plot a 3D vector equation (line) and a plane on the same graph.
    plane_coeffs = (a, b, c, d) for ax + by + cz = d
    """
    a, b, c, d = plane_coeffs

    # Use data-based scale instead of fixed limits
    scale = max(1.0, max(abs(point[0]), abs(point[1]), abs(point[2]),
                         abs(direction[0]), abs(direction[1]), abs(direction[2])))
    t = np.linspace(-scale, scale, 200)
    x_line = point[0] + direction[0] * t
    y_line = point[1] + direction[1] * t
    z_line = point[2] + direction[2] * t

    fig = plt.figure(figsize=(9, 7))
    ax = plt.axes(projection="3d")

    ax.plot(x_line, y_line, z_line, label="Vector line")
    ax.scatter(point[0], point[1], point[2], label="Starting point")

    # Auto-size plane grid from data
    line_min = min(x_line.min(), y_line.min(), z_line.min())
    line_max = max(x_line.max(), y_line.max(), z_line.max())
    intercepts = []
    if abs(a) > EPS:
        intercepts.append(d / a)
    if abs(b) > EPS:
        intercepts.append(d / b)
    if abs(c) > EPS:
        intercepts.append(d / c)
    if intercepts:
        limit = max(abs(line_min), abs(line_max), max(abs(v) for v in intercepts))
    else:
        limit = max(abs(line_min), abs(line_max), 1.0)
    limit = max(limit, 1.0) * 1.2
    grid = np.linspace(-limit, limit, 20)

    if abs(c) > EPS:
        X, Y = np.meshgrid(grid, grid)
        Z = (d - a * X - b * Y) / c
        ax.plot_surface(X, Y, Z, alpha=0.7)
    elif abs(b) > EPS:
        X, Z = np.meshgrid(grid, grid)
        Y = (d - a * X - c * Z) / b
        ax.plot_surface(X, Y, Z, alpha=0.7)
    else:
        Y, Z = np.meshgrid(grid, grid)
        X = (d - b * Y - c * Z) / a
        ax.plot_surface(X, Y, Z, alpha=0.7)

    xmin, xmax = min(x_line.min(), -limit), max(x_line.max(), limit)
    ymin, ymax = min(y_line.min(), -limit), max(y_line.max(), limit)
    zmin, zmax = min(z_line.min(), -limit), max(z_line.max(), limit)

    ax.set_xlim(min(xmin, -limit), max(xmax, limit))
    ax.set_ylim(min(ymin, -limit), max(ymax, limit))
    ax.set_zlim(min(zmin, -limit), max(zmax, limit))
    ax.set_box_aspect([1, 1, 1])

    # Axis lines and origin
    ax.plot([-limit, limit], [0, 0], [0, 0], color="gray", linewidth=1)
    ax.plot([0, 0], [-limit, limit], [0, 0], color="gray", linewidth=1)
    ax.plot([0, 0], [0, 0], [-limit, limit], color="gray", linewidth=1)

    # Intersection or closest point (line-plane)
    denom = a * direction[0] + b * direction[1] + c * direction[2]
    if abs(denom) > EPS:
        t_hit = (d - a * point[0] - b * point[1] - c * point[2]) / denom
        hit = np.array(point) + t_hit * np.array(direction)
        ax.scatter(hit[0], hit[1], hit[2], color="black", s=40, label="Intersection")
    else:
        # Line parallel to plane: show closest point on plane from the line start
        n = np.array([a, b, c], dtype=float)
        n_len_sq = np.dot(n, n)
        if n_len_sq > EPS:
            dist = (a * point[0] + b * point[1] + c * point[2] - d) / n_len_sq
            closest = np.array(point) - dist * n
            ax.scatter(closest[0], closest[1], closest[2], color="black", s=40, label="Closest point")
            ax.plot([point[0], closest[0]], [point[1], closest[1]], [point[2], closest[2]],
                    color="black", linestyle="--", linewidth=1)

    ax.set_xlabel("x")
    ax.set_ylabel("y")
    ax.set_zlabel("z")
    ax.set_title("Vector Line and Plane Comparison")
    ax.legend()
    return fig
    

def visualize_point_line_distance(point_on_line, direction, point, closest):
    """Visualize a point, the line, and the closest point on the line."""
    dim = len(point)
    # Use all relevant coordinates to set a stable plotting scale
    all_vals = np.concatenate([
        np.ravel(point_on_line),
        np.ravel(direction),
        np.ravel(point),
        np.ravel(closest)
    ])
    t_scale = max(1.0, float(np.max(np.abs(all_vals))))
    t = np.linspace(-t_scale, t_scale, 200)

    if dim == 2:
        fig, ax = plt.subplots()
        # Parametric line: P(t) = point_on_line + t * direction
        x_line = point_on_line[0] + direction[0] * t
        y_line = point_on_line[1] + direction[1] * t

        ax.plot(x_line, y_line, label="Line")
        ax.scatter(point[0], point[1], color="red", label="Point")
        ax.scatter(closest[0], closest[1], color="black", label="Closest point")
        # Dashed segment shows the shortest distance
        ax.plot([point[0], closest[0]], [point[1], closest[1]], color="black", linestyle="--")

        # Fit axes to the data so the distance is easy to see
        all_x = np.concatenate([x_line, [point[0], closest[0]]])
        all_y = np.concatenate([y_line, [point[1], closest[1]]])
        xmin, xmax = all_x.min(), all_x.max()
        ymin, ymax = all_y.min(), all_y.max()
        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)

        ax.set_aspect("equal", "box")
        ax.grid(True)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_title("Point to Line Distance (2D)")
        ax.legend()
        return fig

    if dim == 3:
        fig = plt.figure(figsize=(9, 7))
        ax = plt.axes(projection="3d")

        # Parametric line in 3D
        x_line = point_on_line[0] + direction[0] * t
        y_line = point_on_line[1] + direction[1] * t
        z_line = point_on_line[2] + direction[2] * t

        ax.plot(x_line, y_line, z_line, label="Line")
        ax.scatter(point[0], point[1], point[2], color="red", label="Point")
        ax.scatter(closest[0], closest[1], closest[2], color="black", label="Closest point")
        # Shortest segment from point to line
        ax.plot([point[0], closest[0]], [point[1], closest[1]], [point[2], closest[2]],
                color="black", linestyle="--")

        # Tight bounds around the key points
        focus_points = np.array([point_on_line, point, closest], dtype=float)
        all_x = focus_points[:, 0]
        all_y = focus_points[:, 1]
        all_z = focus_points[:, 2]
        xmin, xmax = all_x.min(), all_x.max()
        ymin, ymax = all_y.min(), all_y.max()
        zmin, zmax = all_z.min(), all_z.max()

        ax.set_xlim(xmin, xmax)
        ax.set_ylim(ymin, ymax)
        ax.set_zlim(zmin, zmax)
        ax.set_box_aspect([1, 1, 1])

        # Axis lines and origin
        axis_limit = max(abs(xmin), abs(xmax), abs(ymin), abs(ymax), abs(zmin), abs(zmax))
        ax.plot([-axis_limit, axis_limit], [0, 0], [0, 0], color="gray", linewidth=1)
        ax.plot([0, 0], [-axis_limit, axis_limit], [0, 0], color="gray", linewidth=1)
        ax.plot([0, 0], [0, 0], [-axis_limit, axis_limit], color="gray", linewidth=1)
        ax.scatter(0, 0, 0, color="black", s=20, label="Origin")

        ax.grid(True)
        ax.set_xlabel("x")
        ax.set_ylabel("y")
        ax.set_zlabel("z")
        ax.set_title("Point to Line Distance (3D)")
        ax.legend()
        return fig

#
# PROGRAM ENTRY

main_menu_UI()
plt.show(block=True)
